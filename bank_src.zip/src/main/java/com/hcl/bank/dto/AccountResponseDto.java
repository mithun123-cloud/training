package com.hcl.bank.dto;

public class AccountResponseDto {

}
