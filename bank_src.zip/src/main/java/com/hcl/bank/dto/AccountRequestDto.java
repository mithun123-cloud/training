package com.hcl.bank.dto;

import javax.validation.constraints.Min;

import com.sun.istack.NotNull;

public class AccountRequestDto {

	private long fromAccount;
	@NotNull
	private long toAccount;
	@Min(2)
	private Double amount;

	private String remarks;

	//private String transDate;

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "AccountRequestDto [fromAccount=" + fromAccount + ", toAccount=" + toAccount + ", amount=" + amount
				+ ", remarks=" + remarks + "]";
	}

	/*
	 * public String getTransDate() { return transDate; }
	 * 
	 * public void setTransDate(String transDate) { this.transDate = transDate; }
	 */

}