package com.hcl.bank.exception;

public class DailyWithdrawLimitExceededExecption {

}
