package com.hcl.bank.exception;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
@RestControllerAdvice
public class GlobalResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {


	
	@ExceptionHandler(value = AccountNotFoundException.class)
	protected ResponseEntity<ErrorResponse> handleccountNotFoundException(AccountNotFoundException accountNotFoundException) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("123");
		errorResponse.setStatusMessage(accountNotFoundException.getMessage());
			
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	@ExceptionHandler(value = InsufficientFundsException.class)
	protected ResponseEntity<ErrorResponse> handleInsufficientFoundException(InsufficientFundsException insufficientFoundException) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("1234");
		errorResponse.setStatusMessage(insufficientFoundException.getMessage());			
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	@ExceptionHandler(value = MinimumAmountDepositException.class)
	protected ResponseEntity<ErrorResponse> handleInsuranceNotFoundException(MinimumAmountDepositException miniumAmountDeposit) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("12345");
		errorResponse.setStatusMessage(miniumAmountDeposit.getMessage());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	
	@ExceptionHandler(value = Exception.class)
	protected ResponseEntity<ErrorResponse> handleEexception(Exception exception) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("123456");
		errorResponse.setStatusMessage(exception.getMessage());			
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	@Override
	//@ResponseStatus(HttpStatus.BAD_REQUEST)
    //@ExceptionHandler(MethodArgumentNotValidException.class)
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("1234567");
		
        String errors = ex.getBindingResult().getFieldErrors().stream().map(e -> e.getDefaultMessage()).collect(Collectors.joining(","));
        errorResponse.setStatusMessage(errors);
        return new ResponseEntity<Object>(errorResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(ConstraintViolationException.class)
    public Map<String, String> handleConstraintViolation(ConstraintViolationException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getConstraintViolations().forEach(cv -> {
            errors.put("message", cv.getMessage());
            errors.put("path", (cv.getPropertyPath()).toString());
        });
        return errors;
    }

}
