package com.hcl.bank.controller;
import javax.security.auth.login.AccountNotFoundException;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.bank.dto.AccountRequestDto;
import com.hcl.bank.exception.InsufficientFundsException;
import com.hcl.bank.service.AccountService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
/**
 * @author Mithun Bhadra
 * 
 */
@RestController
@RequestMapping("/bank")
@Api(value = "Account Resource Endpoint.", description = "")
public class AccountController {

	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

	@Autowired
	AccountService accountService;

	@Autowired
	Environment environment;
	
	@ApiOperation(value = "Fund Transfer")
	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "Fund Transfer Successfully"),
					@ApiResponse(code = 404, message = "Not Found")
			}
	)
	
	/**
	 * @param accountRequestDto
	 * @return
	 * @throws AccountNotFoundException
	 * @throws InsufficientFundsException
	 */
	@PostMapping("/fundtransfer")
	public ResponseEntity<String> fundTransfer(@Valid @RequestBody AccountRequestDto accountRequestDto)
			throws AccountNotFoundException, InsufficientFundsException {
		logger.info("fundTransafer::" + accountRequestDto);
		accountService.fundTransfer(accountRequestDto);
		return new ResponseEntity<String>("Fund Transferred Successfully", HttpStatus.OK);
	}
	
	
	/*
	 * @PostMapping("/fundTransfer") public String fundTransfer(@Valid @RequestBody
	 * AccountRequestDto accountRequestDto) throws AccountNotFoundException,
	 * InsufficientFoundException {
	 * logger.info("fundTransafer::"+accountRequestDto);
	 * System.out.println("fundTransafer::1--------"+accountRequestDto);
	 * accountService.fundTransfer(accountRequestDto); return
	 * "Fund Transferred successfully"; }
	 */
	
	/**
	 * 
	 * @return
	 */
	
	@GetMapping("/port")
	public String getInfo() {
		String port = environment.getProperty("local.server.port");
		return "from server" + port;
	}
	
}
