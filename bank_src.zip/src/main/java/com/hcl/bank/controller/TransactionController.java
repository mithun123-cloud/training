package com.hcl.bank.controller;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;
import javax.validation.constraints.Min;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.bank.entity.Transaction;
import com.hcl.bank.service.TransactionService;

import io.swagger.annotations.ApiOperation;
/**
 * @author Mithun Bhadra
 * 
 */

@RestController
@Validated
public class TransactionController {

	private static final Logger logger = LoggerFactory.getLogger(TransactionController.class);

	@Autowired
	TransactionService transactionService;

	/**
	 * @param accountNo
	 * @param pageNumber
	 * @param size
	 * @return
	 * @throws AccountNotFoundException
	 */
	
	@ApiOperation(value = "Get Transactions By AccountNo")
	@GetMapping("/history/{accountNo}")
	public ResponseEntity<List<Transaction>> getTransactionsByAccountNo(@PathVariable("accountNo") @Min(value = 1) Long accountNo,
			@RequestParam int pageNumber, @RequestParam int size) throws AccountNotFoundException {
		logger.info("featchRecords:::"+accountNo);
		List<Transaction> transactionList = transactionService.featchRecords(accountNo, pageNumber, size);
		return new ResponseEntity<List<Transaction>>(transactionList, new HttpHeaders(), HttpStatus.OK);
	}
}
