package com.hcl.bank.constant;


public interface AccountConstant {
	
	String INSUFFICIENTFOUND = "InSufficiet Found.";
	
	String TOACCOUNT = "To Account Number Not Found!";

	String FROMACCOUNT = "From Account Number Not Found";

	String FROMANDTONOTSAME = "FromAccount  and toAccount number shoud Not same";

}
