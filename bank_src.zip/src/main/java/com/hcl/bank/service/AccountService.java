package com.hcl.bank.service;


import javax.security.auth.login.AccountNotFoundException;

import com.hcl.bank.dto.AccountRequestDto;
import com.hcl.bank.entity.Transaction;
import com.hcl.bank.exception.InsufficientFundsException;

public interface AccountService {


	public Transaction fundTransfer(AccountRequestDto AccountRequestDto) throws  AccountNotFoundException, InsufficientFundsException;


}
