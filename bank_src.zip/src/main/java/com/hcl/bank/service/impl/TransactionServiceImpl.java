package com.hcl.bank.service.impl;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hcl.bank.entity.Transaction;
import com.hcl.bank.repository.TransactionRepository;
import com.hcl.bank.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	TransactionRepository transactionRepository;

	private static final Logger logger = LoggerFactory.getLogger(TransactionServiceImpl.class);
	
	@Override
	public List<Transaction> featchRecords(Long accountNo, int pageNumber, int size) throws AccountNotFoundException {
		Pageable pageable = PageRequest.of(pageNumber, size);
		logger.info(
				"featchRecords in service impl::::" + accountNo + "pageNumber::::" + pageNumber + "size:::" + size);
		List<Transaction> stmt = transactionRepository.featchRecords(accountNo, pageable);
		if (stmt.size() == 0) {
			throw new AccountNotFoundException("Given Account number not available ");
		}
		return stmt;
	}
}
