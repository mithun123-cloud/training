package com.hcl.insurance.exception;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(value = CompanyNotFoundException.class)
	protected ResponseEntity<ErrorResponse> handleException(CompanyNotFoundException companyNotFoundException) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("123");
		errorResponse.setStatusMessage(companyNotFoundException.getMessage());
			
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	@ExceptionHandler(value = CustomerNotFoundException.class)
	protected ResponseEntity<ErrorResponse> handleCustomerNotFoundException(CustomerNotFoundException customerNotFoundException) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("1234");
		errorResponse.setStatusMessage(customerNotFoundException.getMessage());			
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	
	@ExceptionHandler(value = Exception.class)
	protected ResponseEntity<ErrorResponse> handleEexception(Exception exception) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("12345");
		errorResponse.setStatusMessage(exception.getMessage());			
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	@ExceptionHandler(value = InsuranceNotFoundException.class)
	protected ResponseEntity<ErrorResponse> handleInsuranceNotFoundException(InsuranceNotFoundException insuranceNotFoundException) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("123456");
		errorResponse.setStatusMessage(insuranceNotFoundException.getMessage());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.BAD_REQUEST); 
	}
	
	/*
	 * @ResponseStatus(HttpStatus.BAD_REQUEST)
	 * 
	 * @ExceptionHandler(MethodArgumentNotValidException.class) public Map<String,
	 * String> h(MethodArgumentNotValidException ex) { Map<String, String> errors =
	 * new HashMap<>(); ex.getBindingResult().getFieldErrors() .forEach(error ->
	 * errors.put(error.getField(), error.getDefaultMessage())); return errors; }
	 */
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("1234567");
        String errors = ex.getBindingResult().getFieldErrors().stream().map(e -> e.getDefaultMessage()).collect(Collectors.joining(","));
        errorResponse.setStatusMessage(errors);
        return new ResponseEntity<Object>(errorResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(ConstraintViolationException.class)
    public Map<String, String> handleConstraintViolation(ConstraintViolationException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getConstraintViolations().forEach(cv -> {
            errors.put("message", cv.getMessage());
            errors.put("path", (cv.getPropertyPath()).toString());
        });
        return errors;
    }
	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers,
		     HttpStatus status, WebRequest request) {
		ErrorResponse  errorResponse = new ErrorResponse();
		errorResponse.setStatusCode("123456");
		errorResponse.setStatusMessage(ex.getMessage());
		   // String error = ex.getParameterName() + " parameter is missing.";
		    return new ResponseEntity<Object>(errorResponse, HttpStatus.BAD_REQUEST);
		   }
}
