package com.hcl.insurance.service.impl;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.insurance.constant.InsuranceConstant;
import com.hcl.insurance.dto.CustomerDto;
import com.hcl.insurance.entity.Customer;
import com.hcl.insurance.exception.CustomerNotFoundException;
import com.hcl.insurance.repository.CustomerRepository;
import com.hcl.insurance.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public List<Customer> getCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addCustomer(@Valid CustomerDto customerDto) throws CustomerNotFoundException {

		Customer customer = new Customer();
		
		BeanUtils.copyProperties(customerDto, customer);
		
		customerRepository.save(customer);
		
		String message = "";
		if (customerRepository.findById(customer.getCustomerId()).isPresent()) {
			message = InsuranceConstant.SUCCESSFULLYSAVE;
		} else {
			throw new CustomerNotFoundException(InsuranceConstant.CUSTOMERNOTFOUND);
		}
		return message;
	}

}
