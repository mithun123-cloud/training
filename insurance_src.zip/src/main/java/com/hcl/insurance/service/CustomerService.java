package com.hcl.insurance.service;

import java.util.List;

import javax.validation.Valid;

import com.hcl.insurance.dto.CustomerDto;
import com.hcl.insurance.entity.Customer;
import com.hcl.insurance.exception.CustomerNotFoundException;

public interface CustomerService {

	List<Customer> getCustomer();

	String addCustomer(@Valid CustomerDto customerDto) throws CustomerNotFoundException;

}
