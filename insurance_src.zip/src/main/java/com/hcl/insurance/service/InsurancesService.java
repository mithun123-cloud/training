package com.hcl.insurance.service;

import java.util.List;

import com.hcl.insurance.dto.InsurancesResponseDto;
import com.hcl.insurance.entity.Insurances;

public interface InsurancesService {

	List<Insurances> listInsurances();

	List<InsurancesResponseDto> listInsurancesByName(String insuranceName);

}
