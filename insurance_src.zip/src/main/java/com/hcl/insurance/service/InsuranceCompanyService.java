package com.hcl.insurance.service;

import java.util.List;

import com.hcl.insurance.dto.InsuranceCompanyDto;
import com.hcl.insurance.entity.InsuranceCompany;
import com.hcl.insurance.exception.CompanyNameNotFoundException;

public interface InsuranceCompanyService {

	List<InsuranceCompanyDto> listInsuranceCompanies();
	List<InsuranceCompany> listInsuranceCompaniesByName(String comapanyName) throws CompanyNameNotFoundException;

}
