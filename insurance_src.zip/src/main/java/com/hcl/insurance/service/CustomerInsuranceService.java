package com.hcl.insurance.service;

import java.util.List;

import com.hcl.insurance.dto.CustomerInsuranceRequestDto;
import com.hcl.insurance.dto.CustomerInsuranceResponseDto;
import com.hcl.insurance.exception.CustomerNotFoundException;
import com.hcl.insurance.exception.InsuranceNotFoundException;

public interface CustomerInsuranceService {

	String optingInsurance(CustomerInsuranceRequestDto customerInsuranceDto) throws CustomerNotFoundException, InsuranceNotFoundException, Exception;

	List<CustomerInsuranceResponseDto> searchCustomers(Integer customerId, Integer pageNumber, Integer pageSize) throws CustomerNotFoundException;

}
