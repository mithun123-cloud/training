package com.hcl.insurance.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.insurance.constant.InsuranceConstant;
import com.hcl.insurance.dto.InsuranceCompanyDto;
import com.hcl.insurance.entity.InsuranceCompany;
import com.hcl.insurance.exception.CompanyNameNotFoundException;
import com.hcl.insurance.repository.InsuranceCompanyRepository;
import com.hcl.insurance.service.InsuranceCompanyService;

@Service
public class InsuranceCompanyServiceImpl implements InsuranceCompanyService {

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	private static final Logger logger = LoggerFactory.getLogger(InsuranceCompanyServiceImpl.class);

	@Override
	public List<InsuranceCompanyDto> listInsuranceCompanies() {

		/*
		 * System.out.println("listInsuranceCompanies----service---->");
		 * List<InsuranceCompany> companyList = insuranceCompanyRepository.findAll();
		 * System.out.println("companyList------->" + companyList.toString());
		 * InsuranceCompanyDto insuranceCompanyDto = new InsuranceCompanyDto();
		 * List<InsuranceCompanyDto> insuranceCompanyDtoList = new ArrayList<>(); for
		 * (InsuranceCompany insuranceCompany : companyList) {
		 * BeanUtils.copyProperties(insuranceCompany, insuranceCompanyDto);
		 * System.out.println("insuranceCompanyDto---->" +
		 * insuranceCompanyDto.toString());
		 * insuranceCompanyDtoList.add(insuranceCompanyDto); }
		 * 
		 * return insuranceCompanyDtoList;
		 * 
		 */
		System.out.println("listInsuranceCompanies----->");
		logger.info("listInsuranceCompanies----->");
		List<InsuranceCompany> list = insuranceCompanyRepository.findAll();
		List<InsuranceCompanyDto> employeeList = list.stream().map(InsuranceCompanyDto::new)
				.collect(Collectors.toCollection(ArrayList::new));
		return employeeList;
	}

	@Override
	public List<InsuranceCompany> listInsuranceCompaniesByName(String comapanyName) throws CompanyNameNotFoundException {
		System.out.println("listInsuranceCompaniesByName...");
		logger.info("listInsuranceCompaniesByName...");
		List<InsuranceCompany> comapanyNameList = insuranceCompanyRepository.findByCompanyNameContains(comapanyName);
		
		if(comapanyNameList.size() != 0 ){
			return comapanyNameList;

		} else {
			throw new CompanyNameNotFoundException(InsuranceConstant.COMPANYNAME);
		}
	}

}
