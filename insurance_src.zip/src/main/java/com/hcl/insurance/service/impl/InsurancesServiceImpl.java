package com.hcl.insurance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.insurance.dto.InsurancesResponseDto;
import com.hcl.insurance.entity.Insurances;
import com.hcl.insurance.repository.InsurancesRepository;
import com.hcl.insurance.service.InsurancesService;

@Service
public class InsurancesServiceImpl implements InsurancesService {

	@Autowired
	InsurancesRepository insurancesRepository;

	private static final Logger logger = LoggerFactory.getLogger(InsurancesServiceImpl.class);

	@Override
	public List<Insurances> listInsurances() {
		// TODO Auto-generated method stub
		return insurancesRepository.findAll();
	}

	@Override
	public List<InsurancesResponseDto> listInsurancesByName(String insuranceName) {

		List<Insurances> insuranceList = insurancesRepository.findByInsuranceNameContains(insuranceName);

		logger.info("insuranceList::" + insuranceList);

		List<InsurancesResponseDto> insurancesDtoList = new ArrayList<>();

		InsurancesResponseDto insurancesDtos = null;

		for (Insurances insurance : insuranceList) {
			insurancesDtos = new InsurancesResponseDto();

			BeanUtils.copyProperties(insurance, insurancesDtos);

			insurancesDtos.setInsuranceCompanyName(insurance.getInsuranceCompany().getCompanyName());

			insurancesDtoList.add(insurancesDtos);
		}
		return insurancesDtoList;
	}

}
