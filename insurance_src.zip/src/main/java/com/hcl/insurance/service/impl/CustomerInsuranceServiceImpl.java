package com.hcl.insurance.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hcl.insurance.constant.InsuranceConstant;
import com.hcl.insurance.dto.AccountRequestDto;
import com.hcl.insurance.dto.CustomerInsuranceRequestDto;
import com.hcl.insurance.dto.CustomerInsuranceResponseDto;
import com.hcl.insurance.dto.InsuranceRequestDto;
import com.hcl.insurance.entity.Customer;
import com.hcl.insurance.entity.CustomerInsurance;
import com.hcl.insurance.entity.Insurances;
import com.hcl.insurance.exception.CustomerNotFoundException;
import com.hcl.insurance.exception.InsuranceNotFoundException;
import com.hcl.insurance.feignclient.BankServiceProxy;
import com.hcl.insurance.repository.CustomerInsurancesRepository;
import com.hcl.insurance.repository.CustomerRepository;
import com.hcl.insurance.repository.InsurancesRepository;
import com.hcl.insurance.service.CustomerInsuranceService;

@Service
public class CustomerInsuranceServiceImpl implements CustomerInsuranceService {

	@Autowired
	CustomerInsurancesRepository customerInsurancesRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	InsurancesRepository insurancesRepository;

	@Autowired
	BankServiceProxy bankServiceProxy;

	private static final Logger logger = LoggerFactory.getLogger(CustomerInsuranceServiceImpl.class);

	@Override
	@Transactional
	public String optingInsurance(CustomerInsuranceRequestDto customerInsuranceDto)
			throws CustomerNotFoundException, InsuranceNotFoundException, Exception {

		CustomerInsurance customerinsurance = new CustomerInsurance();
		double totalAmount = 0;

		if (!customerRepository.findById(customerInsuranceDto.getCustomerId()).isPresent()) {
			throw new CustomerNotFoundException(InsuranceConstant.CUSTOMERNOTFOUND);
		}

		Map<Long, Double> insuranceMap = new HashMap<>();
		Map<Long, Double> insuranceResult = new HashMap<>();

		Integer customerId  = customerRepository.findById(customerInsuranceDto.getCustomerId()).get().getCustomerId();
		
		for (InsuranceRequestDto insuranceDto : customerInsuranceDto.getInsuranceRequestDto()) {
			CustomerInsurance customerInsurance = new CustomerInsurance();

			/*
			 * customerInsurance.setCustomerId(
			 * customerRepository.findById(customerInsuranceDto.getCustomerId()).get().
			 * getCustomerId());
			 */
			customerInsurance.setCustomerId(customerId);
			customerInsurance.setDate(Calendar.getInstance().getTime());
			Optional<Insurances> insurance = insurancesRepository.findById(insuranceDto.getInsuranceId());

			if (insurance.isPresent()) {
				customerInsurance.setInsurances(insurance.get());

				totalAmount = totalAmount + insuranceDto.getAmount();

				insuranceResult = insurancePayment(insurance.get(), insuranceMap, insuranceDto.getAmount());

				customerInsurance.setPremiumAmount(insuranceDto.getAmount());

				customerInsurance.setStatus(InsuranceConstant.SUCCESS);

				customerInsurancesRepository.save(customerInsurance);
			} else {
				throw new InsuranceNotFoundException(InsuranceConstant.INSURANCENOTFOUND);
			}
		}
		if (totalAmount == 0) {
			return null;
		}
		customerinsurance.setPremiumAmount(totalAmount);

		String status = "";
		AccountRequestDto accountRequestDto = new AccountRequestDto();

		accountRequestDto.setFromAccount(customerInsuranceDto.getFromAccount());

		accountRequestDto.setRemarks(InsuranceConstant.REMARK);

		for (Map.Entry<Long, Double> insuranceSet : insuranceResult.entrySet()) {

			accountRequestDto.setToAccount(insuranceSet.getKey());

			accountRequestDto.setAmount(insuranceSet.getValue());

			status = bankServiceProxy.fundTransafer(accountRequestDto);

			logger.info("status:::" + status);
		}
		return InsuranceConstant.MESSAGE;
	}

	private Map<Long, Double> insurancePayment(Insurances insurances, Map<Long, Double> insurancePaymentMap,
			double amount) {
		if (insurancePaymentMap.size() > 0) {
			Iterator<Long> iterator = insurancePaymentMap.keySet().iterator();

			while (iterator.hasNext()) {
				Long key = iterator.next();
				Double value = insurancePaymentMap.get(key);
				
				logger.info("CompanyAccountNumber::--->" + insurances.getInsuranceCompany().getCompanyAccountNumber());
				if (key.equals(insurances.getInsuranceCompany().getCompanyAccountNumber())) {
					insurancePaymentMap.replace(key, value + Double.valueOf(amount));
				} else {
					insurancePaymentMap.put(insurances.getInsuranceCompany().getCompanyAccountNumber(),
							Double.valueOf(amount));
				}
			}
		} else {
			insurancePaymentMap.put(insurances.getInsuranceCompany().getCompanyAccountNumber(), Double.valueOf(amount));
		}
		return insurancePaymentMap;
	}

	@Override
	public List<CustomerInsuranceResponseDto> searchCustomers(Integer customerId, Integer pageNumber, Integer pageSize)
			throws CustomerNotFoundException {
		List<CustomerInsuranceResponseDto> customerInsuranceResponseDtoList = new ArrayList<>();
		logger.info("serchUserOrderByUserId in service..." + customerId);
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		List<CustomerInsurance> customerInsuranceList = customerInsurancesRepository.findByCustomerId(customerId,
				pageable);

		if (customerInsuranceList.size() >= 1) {
			CustomerInsuranceResponseDto customerInsuranceResponseDto = null;
			
			for (CustomerInsurance customerInsurance : customerInsuranceList) {
			//	customerInsuranceList.stream().forEach(action
				logger.info("customerInsuranceList:::" + customerInsuranceList);
				customerInsuranceResponseDto = new CustomerInsuranceResponseDto();
				BeanUtils.copyProperties(customerInsurance, customerInsuranceResponseDto);

				Optional<Customer> customer = customerRepository.findById(customerInsurance.getCustomerId());
				
				if (customer.isPresent()) {

					logger.info("cust.get().getCustomerName()---->" + customer.get().getCustomerName());

					customerInsuranceResponseDto.setCustomerName(customer.get().getCustomerName());

					customerInsuranceResponseDtoList.add(customerInsuranceResponseDto);
				} else {
					throw new CustomerNotFoundException(InsuranceConstant.CUSTOMERNOTFOUND);
				}
			}
		} else {
			throw new CustomerNotFoundException(InsuranceConstant.CUSTOMERNOTFOUND);
		}
		return customerInsuranceResponseDtoList;
	}
}
