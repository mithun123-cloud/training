package com.hcl.insurance.constant;

public interface InsuranceConstant {

	String MESSAGE = "Successfully Optaining The Insurance.";
	//String REMARK = "Breakfast";
	String REMARK = "Payment For Insurance";
	String SUCCESS = "Success";
	
	String INSURANCENOTFOUND = "Insurance Id Not Found.";
	String CUSTOMERNOTFOUND = "Customer Not Found.";
	String SUCCESSFULLYSAVE = "Succesfully Save.";
	String COMPANYNAME = "Company Name Not Found.";

}
