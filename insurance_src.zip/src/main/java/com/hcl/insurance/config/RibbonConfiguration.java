
package com.hcl.insurance.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AvailabilityFilteringRule;
import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.RandomRule;

public class RibbonConfiguration {

	@Autowired
	IClientConfig iClientConfig;

	@Bean
	public IRule randomRule(IClientConfig iClientConfig) {
		return new RandomRule();
	}

	@Bean
	public IRule ribbonRule(IClientConfig iClientConfig) {
		return new AvailabilityFilteringRule();
	}

}
