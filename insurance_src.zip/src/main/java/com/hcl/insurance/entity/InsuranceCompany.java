package com.hcl.insurance.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * @author Mithun Bhadra
 */
@Entity
@Table(name = "T_COMPANY")
public class InsuranceCompany implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "company_id")
	private Integer companyId;

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "company_phoneNumber")
	private String companyPhoneNumber;

	@Column(name = "company_emailAddress")
	private String companyEmailAddress;

	@Column(name = "company_address")
	private String companyAddress;

	@Column(name = "company_account_number")
	private Long companyAccountNumber;

	@OneToMany(mappedBy = "insuranceCompany")
	@JsonManagedReference
	private List<Insurances> insurances = new ArrayList<>();

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public Long getCompanyAccountNumber() {
		return companyAccountNumber;
	}

	public void setCompanyAccountNumber(Long companyAccountNumber) {
		this.companyAccountNumber = companyAccountNumber;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyPhoneNumber() {
		return companyPhoneNumber;
	}

	public void setCompanyPhoneNumber(String companyPhoneNumber) {
		this.companyPhoneNumber = companyPhoneNumber;
	}

	public String getCompanyEmailAddress() {
		return companyEmailAddress;
	}

	public void setCompanyEmailAddress(String companyEmailAddress) {
		this.companyEmailAddress = companyEmailAddress;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public List<Insurances> getInsurances() {
		return insurances;
	}

	public void setInsurances(List<Insurances> insurances) {
		this.insurances = insurances;
	}

	@Override
	public String toString() {
		return "InsuranceCompany [companyId=" + companyId + ", companyName=" + companyName + ", companyPhoneNumber="
				+ companyPhoneNumber + ", companyEmailAddress=" + companyEmailAddress + ", companyAddress="
				+ companyAddress + ", companyAccountNumber=" + companyAccountNumber + ", insurances=" + insurances
				+ "]";
	}

}
