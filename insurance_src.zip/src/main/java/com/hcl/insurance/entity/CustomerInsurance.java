package com.hcl.insurance.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Mithun Bhadra
 */
@Entity
@Table(name = "T_CUSTOMER_INSURANCE")
public class CustomerInsurance implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "insurance_number")
	private Long insuranceNumber;

	@Column(name = "customer_id")
	private Integer customerId;

	@JsonFormat(pattern = "dd/MM/yyyy hh:mm")
	@Column(name = "date")
	private Date date;
	
	//@JsonFormat(pattern = "yyyy-MM-dd")
    //private LocalDate birthday;

	@Column(name = "premium_amount")
	private Double premiumAmount;

	private String status;

	@ManyToOne
	private Insurances insurances;

	public Long getInsuranceNumber() {
		return insuranceNumber;
	}

	public void setInsuranceNumber(Long insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Insurances getInsurances() {
		return insurances;
	}

	public void setInsurances(Insurances insurances) {
		this.insurances = insurances;
	}

}
