package com.hcl.insurance.entity;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;


/**
 * @author Mithun Bhadra
 */
@Entity
@Table(name = "T_INSURANCES")
public class Insurances implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "insurance_id")
	private Integer insuranceId;

	@Column(name = "insurance_name")
	private String insuranceName;

	@Column(name = "insurance_description")
	private String insuranceDescription;

	@Column(name = "sumInsured")
	private String sumInsured;

	@Column(name = "insurance_tenure")
	private String insuranceTenure;

	@Column(name = "insurance_benefit_amount")
	private String insuranceBenifitAmount;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "company_id")
	@JsonBackReference
	private InsuranceCompany insuranceCompany;

	public Integer getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(Integer insuranceId) {
		this.insuranceId = insuranceId;
	}

	public String getInsuranceName() {
		return insuranceName;
	}

	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}

	public String getInsuranceDescription() {
		return insuranceDescription;
	}

	public void setInsuranceDescription(String insuranceDescription) {
		this.insuranceDescription = insuranceDescription;
	}

	public String getSumInsured() {
		return sumInsured;
	}

	public void setSumInsured(String sumInsured) {
		this.sumInsured = sumInsured;
	}

	public String getInsuranceTenure() {
		return insuranceTenure;
	}

	public void setInsuranceTenure(String insuranceTenure) {
		this.insuranceTenure = insuranceTenure;
	}

	public String getInsuranceBenifitAmount() {
		return insuranceBenifitAmount;
	}

	public void setInsuranceBenifitAmount(String insuranceBenifitAmount) {
		this.insuranceBenifitAmount = insuranceBenifitAmount;
	}

	public InsuranceCompany getInsuranceCompany() {
		return insuranceCompany;
	}

	public void setInsuranceCompany(InsuranceCompany insuranceCompany) {
		this.insuranceCompany = insuranceCompany;
	}

}
