package com.hcl.insurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.insurance.dto.InsurancesResponseDto;
import com.hcl.insurance.entity.Insurances;
import com.hcl.insurance.service.InsurancesService;

import io.swagger.annotations.Api;
/**
 * @author Mithun Bhadra
 * 
 */
@RestController
@Api(value = "Insurances Resource Endpoint.", description = "")
public class InsurancesController {

	@Autowired
	InsurancesService insurancesService;

	/**
	 * @return list of insurances
	 */
	@GetMapping("/insurance")
	public ResponseEntity<List<Insurances>> getCompanies() {
		return new ResponseEntity<List<Insurances>>(insurancesService.listInsurances(), HttpStatus.OK);

	}

	/**
	 * @param insuranceName
	 * @return List insurance based on insurnace name
	 */
	@GetMapping("/insurances/{insuranceName}")
	public ResponseEntity<List<InsurancesResponseDto>> getCompaniesByName(
			@PathVariable("insuranceName") String insuranceName) {
		return new ResponseEntity<List<InsurancesResponseDto>>(insurancesService.listInsurancesByName(insuranceName),
				HttpStatus.OK);

	}
}
