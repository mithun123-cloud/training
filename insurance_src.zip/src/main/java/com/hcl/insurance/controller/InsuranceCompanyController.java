package com.hcl.insurance.controller;

import java.util.List;

import javax.validation.constraints.NotBlank;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.insurance.dto.InsuranceCompanyDto;
import com.hcl.insurance.entity.InsuranceCompany;
import com.hcl.insurance.exception.CompanyNameNotFoundException;
import com.hcl.insurance.service.InsuranceCompanyService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
/**
 * @author Mithun Bhadra
 * 
 */
@RestController
@Api(value = "Insurance Company  Resource Endpoint.", description = "")
public class InsuranceCompanyController {

	private static final Logger logger = LoggerFactory.getLogger(InsuranceCompanyController.class);
	
	@Autowired
	InsuranceCompanyService insuranceCompanyService;

	
	
	/**
	 * @return Get Insurances
	 */
	@ApiOperation(value = "Get Insurances")
	@GetMapping("/insurances")
	public ResponseEntity<List<InsuranceCompanyDto>> getInsurances() {
		logger.info("getCompanies----->");
		return new ResponseEntity<List<InsuranceCompanyDto>>(insuranceCompanyService.listInsuranceCompanies(),
				HttpStatus.OK);
	}

	
	
	/**
	 * 
	 * @param companyName
	 * @return
	 * @throws CompanyNameNotFoundException
	 */
	@ApiOperation(value = "Get Insurances by company name")
	@GetMapping("/companies/{companyName}")
	public ResponseEntity<List<InsuranceCompany>> getCompaniesByName(@PathVariable("companyName") @NotBlank String companyName) throws CompanyNameNotFoundException {
		return new ResponseEntity<List<InsuranceCompany>>(
				insuranceCompanyService.listInsuranceCompaniesByName(companyName), HttpStatus.OK);

	}
}
