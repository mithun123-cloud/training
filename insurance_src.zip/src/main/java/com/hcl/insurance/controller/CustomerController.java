package com.hcl.insurance.controller;

import java.util.List;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hcl.insurance.dto.CustomerDto;
import com.hcl.insurance.entity.Customer;
import com.hcl.insurance.exception.CustomerNotFoundException;
import com.hcl.insurance.repository.CustomerRepository;
import com.hcl.insurance.service.CustomerService;
import io.swagger.annotations.Api;

/**
 * @author Mithun Bhadra
 */
@RestController
@Api(value = "Customer Resource Endpoint.", description = "")
public class CustomerController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	CustomerService customerService;

	@Autowired
	CustomerRepository customerRepository;

	/**
	 * 
	 * @return List of Customers
	 */
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getCustomers() {
		return new ResponseEntity<List<Customer>>(customerService.getCustomer(), HttpStatus.OK);
	}

	/**
	 * 
	 * @param customerDto
	 * @return
	 * @throws CustomerNotFoundException
	 */
	@PostMapping("/customer")
	public ResponseEntity<String> addCustomer(@Valid @RequestBody CustomerDto customerDto)
			throws CustomerNotFoundException {
		logger.info("addCustomer------>");
		String message = customerService.addCustomer(customerDto);
		return new ResponseEntity<String>(message, HttpStatus.OK);
	}

}
