package com.hcl.insurance.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Min;
//https://www.javaquery.com/2018/02/passing-and-validating-requestparam-in.html

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.insurance.dto.CustomerInsuranceRequestDto;
import com.hcl.insurance.dto.CustomerInsuranceResponseDto;
import com.hcl.insurance.exception.CustomerNotFoundException;
import com.hcl.insurance.service.CustomerInsuranceService;
import com.hcl.insurance.service.impl.CustomerInsuranceServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
/**
 * @author Mithun Bhadra
 * 
 */
@Validated
@RestController
@Api(value = "Customer Insurance Resource Endpoint.", description = "")
public class CustomerInsuranceController {

	@Autowired
	CustomerInsuranceService customerInsuranceService;
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerInsuranceServiceImpl.class);

	@ApiOperation(value = "Opting Insurances")
	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "Successfully"),
					@ApiResponse(code = 404, message = "Not Found")
			}
	)
	/**
	 * 
	 * @param customerInsuranceDto
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insurances")
	public ResponseEntity<String> optingInsurances(@Valid @RequestBody CustomerInsuranceRequestDto customerInsuranceDto)
			throws Exception {
		String message = customerInsuranceService.optingInsurance(customerInsuranceDto);
		return new ResponseEntity<String>(message, HttpStatus.CREATED);
	}

	
	
	/**
	 * @param customerId
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 * @throws CustomerNotFoundException
	 */
	@ApiOperation(value = "Get Insurances By Customer Id")
	//@GetMapping("/customerinsurance/{customerId}")//customers/{customerId}/insurances
	@GetMapping("customers/{customerId}/insurances")//@RequestParam("pageNumber")
	public ResponseEntity<List<CustomerInsuranceResponseDto>> getInsurancesByCustomerId(
			@PathVariable("customerId") @Min(value = 1) Integer customerId, @RequestParam(required = false) Integer pageNumber,
			@RequestParam("pageSize") Integer pageSize) throws CustomerNotFoundException {
		logger.info("customerId::" + customerId);
		return new ResponseEntity<List<CustomerInsuranceResponseDto>>(
				customerInsuranceService.searchCustomers(customerId, pageNumber, pageSize), HttpStatus.OK);
	}
}
