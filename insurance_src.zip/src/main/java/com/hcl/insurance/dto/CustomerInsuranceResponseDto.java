package com.hcl.insurance.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcl.insurance.entity.Insurances;

public class CustomerInsuranceResponseDto {

	private Long insuranceNumber;

	//private Integer customerId;
	
	private String customerName;

	@JsonFormat(pattern = "dd/MM/yyyy hh:mm")
	private Date date;

	private Double premiumAmount;

	private Insurances insurances;

	
	
	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/*
	 * public Integer getCustomerId() { return customerId; }
	 * 
	 * public void setCustomerId(Integer customerId) { this.customerId = customerId;
	 * }
	 */
	
	public Long getInsuranceNumber() {
		return insuranceNumber;
	}

	public void setInsuranceNumber(Long insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Insurances getInsurances() {
		return insurances;
	}

	public void setInsurances(Insurances insurances) {
		this.insurances = insurances;
	}

}
