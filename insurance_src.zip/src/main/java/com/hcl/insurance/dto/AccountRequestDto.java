package com.hcl.insurance.dto;

public class AccountRequestDto {

	private long fromAccount;

	private long toAccount;

	private Double amount;

	private String remarks;

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	/*
	 * public String getTransDate() { return transDate; }
	 * 
	 * public void setTransDate(String transDate) { this.transDate = transDate; }
	 */

}