package com.hcl.insurance.dto;

import java.util.ArrayList;
import java.util.List;

import com.hcl.insurance.entity.InsuranceCompany;
import com.hcl.insurance.entity.Insurances;

public class InsuranceCompanyDto {
	
	
	private Integer companyId;

	private String companyName;

	private String companyPhoneNumber;

	private String companyEmailAddress;

	private String companyAddress;

	private Long companyAccountNumber;

	private List<Insurances> insurances = new ArrayList<>();
	
	
	public InsuranceCompanyDto() {}
	

	public InsuranceCompanyDto(InsuranceCompany insuranceCompanyD) {
		super();
		this.companyId = insuranceCompanyD.getCompanyId();
		this.companyName = insuranceCompanyD.getCompanyName();
		this.companyPhoneNumber = insuranceCompanyD.getCompanyPhoneNumber();
		this.companyEmailAddress = insuranceCompanyD.getCompanyEmailAddress();
		this.companyAddress = insuranceCompanyD.getCompanyAddress();
		this.companyAccountNumber = insuranceCompanyD.getCompanyAccountNumber();
		this.insurances = insuranceCompanyD.getInsurances();
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyPhoneNumber() {
		return companyPhoneNumber;
	}

	public void setCompanyPhoneNumber(String companyPhoneNumber) {
		this.companyPhoneNumber = companyPhoneNumber;
	}

	public String getCompanyEmailAddress() {
		return companyEmailAddress;
	}

	public void setCompanyEmailAddress(String companyEmailAddress) {
		this.companyEmailAddress = companyEmailAddress;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public Long getCompanyAccountNumber() {
		return companyAccountNumber;
	}

	public void setCompanyAccountNumber(Long companyAccountNumber) {
		this.companyAccountNumber = companyAccountNumber;
	}

	public List<Insurances> getInsurances() {
		return insurances;
	}

	public void setInsurances(List<Insurances> insurances) {
		this.insurances = insurances;
	}

	@Override
	public String toString() {
		return "InsuranceCompanyDto [companyId=" + companyId + ", companyName=" + companyName + ", companyPhoneNumber="
				+ companyPhoneNumber + ", companyEmailAddress=" + companyEmailAddress + ", companyAddress="
				+ companyAddress + ", companyAccountNumber=" + companyAccountNumber + ", insurances=" + insurances
				+ "]";
	}
	
}
