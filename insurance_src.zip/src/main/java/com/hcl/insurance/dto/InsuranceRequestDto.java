package com.hcl.insurance.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class InsuranceRequestDto {
	
	@NotNull(message = "nsurance Id Should Not Be Null, Please Enter Insurance Id")
	@Min(value = 1)
	private Integer insuranceId;
	
	@NotNull(message = "Amount Should Not Be Null, Please Enter Amount")
	@Min(value = 1)
	private Double amount;
	
	
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Integer getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(Integer insuranceId) {
		this.insuranceId = insuranceId;
	}
	
	

}
