package com.hcl.insurance.dto;

import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

public class CustomerDto {
	
	private Integer customerId;
	
	@NotEmpty(message = "customerAadharCard not empty")
	@Length(min = 12, max = 16, message = "customer Aadhar Card length must be between 12 and 16")
	private String customerAadharCard;

	@NotEmpty(message = "customerFirstName not empty")
	@Length(min= 3, max = 15, message = "customer FirstName length must be between 3 and 15")
	private String customerFirstName;

	@NotEmpty(message = "customerLastName not empty")
	@Length(min= 3, max = 15, message = "customer LastName length must be between 3 and 15")
	private String customerLastName;
	
	@NotEmpty(message = "customerGender not empty")
	private String customerGender;

	private Date customerDOB;

	@Email
	private String customerEmail;

	@NotEmpty(message = "customerAddress not empty")
	private String customerAddress;

	@NotNull
	@NotBlank(message="Please enter your phone number")
	@Pattern(regexp = "(^$|[0-9]{10})" ,message = "Please enter valid phone number")
	private String customerPhone;

	@NotEmpty(message = "customerName not empty")
	@Size(min= 1, max = 25, message = "customer Name  length must be between 1 and 25")
	private String customerName;

	@Max(value = 9000000)
	private Integer customerPassword;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerAadharCard() {
		return customerAadharCard;
	}

	public void setCustomerAadharCard(String customerAadharCard) {
		this.customerAadharCard = customerAadharCard;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public String getCustomerGender() {
		return customerGender;
	}

	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}

	public Date getCustomerDOB() {
		return customerDOB;
	}

	public void setCustomerDOB(Date customerDOB) {
		this.customerDOB = customerDOB;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(Integer customerPassword) {
		this.customerPassword = customerPassword;
	}
	
}
