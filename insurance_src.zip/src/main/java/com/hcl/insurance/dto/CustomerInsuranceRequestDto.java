package com.hcl.insurance.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class CustomerInsuranceRequestDto {

	@NotNull(message = "From Account Number Should Not Be Null, Please Enter From Account")
	@Min(value = 1)
	private Long fromAccount;

	@NotNull(message = "Customer Id Should Not Be Null, Please Enter Customer Id")
	@Min(value = 1)
	private Integer customerId;

	private List<InsuranceRequestDto> InsuranceRequestDto = new ArrayList<>();

	public Long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(Long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public List<InsuranceRequestDto> getInsuranceRequestDto() {
		return InsuranceRequestDto;
	}

	public void setInsuranceRequestDto(List<InsuranceRequestDto> insuranceRequestDto) {
		InsuranceRequestDto = insuranceRequestDto;
	}

}
