
package com.hcl.insurance.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.hcl.insurance.dto.AccountRequestDto;

@FeignClient(name = "http://BANK-SERVICE/bank")
public interface BankServiceProxy {

	@PostMapping(path = "/fundTransfer", produces = "application/json")
	public String fundTransafer(@RequestBody AccountRequestDto accountRequestDto);

	@GetMapping("/port")
	public String getInfo();

}
